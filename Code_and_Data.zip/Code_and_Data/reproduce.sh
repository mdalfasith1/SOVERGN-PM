#!/usr/bin/env bash
# Reproduce every number, table and figure of the manuscript and Supplementary Material.
set -euo pipefail
cd "$(dirname "$0")"
export MPLBACKEND=Agg
python sovereign_pm.py 2>&1 | tee run.log
echo "Outputs written to sovereign_pm_outputs/"
