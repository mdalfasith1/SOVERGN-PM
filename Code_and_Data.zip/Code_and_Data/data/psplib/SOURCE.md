# Benchmark instance files

These two files are used only by the benchmark-topology evaluation (Section 12 of the
script; "Evaluation on genuine benchmark topologies" in the manuscript).

| File | Library | Jobs (incl. dummies) | Modes per job | Renewable capacities |
|---|---|---|---|---|
| `m11_1.mm` | PSPLIB multi-mode set (Kolisch and Sprecher, 1997) | 18 | 1 | [12, 9] |
| `Jall1_1.mm` | MMLIB (Van Peteghem and Vanhoucke, 2014) | 52 | 3 | [33, 33] |

Both files are unmodified copies of the test fixtures distributed with the open-source
`psplib` parser (https://github.com/PyJobShop/PSPLIB, `tests/data/`, MIT License,
commit 55ad8b2b514a444fe5bc1c7afeb6dd0879e5ad74). The original libraries are available from
https://www.om-db.wi.tum.de/psplib/ (PSPLIB) and https://www.projectmanagement.ugent.be/research/data
(MMLIB). Please cite the original libraries when reusing them:

* Kolisch, R., and Sprecher, A. (1997). PSPLIB - A project scheduling problem library.
  European Journal of Operational Research 96, 205-216. doi: 10.1016/S0377-2217(96)00170-1
* Van Peteghem, V., and Vanhoucke, M. (2014). An experimental investigation of metaheuristics
  for the multi-mode resource-constrained project scheduling problem on new dataset instances.
  European Journal of Operational Research 235, 62-72. doi: 10.1016/j.ejor.2013.10.012

The non-renewable resources declared in `Jall1_1.mm` are parsed but not used: Sovereign-PM
models a monetary budget instead.
