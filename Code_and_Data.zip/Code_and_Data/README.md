# Sovereign-PM: reference implementation

Code accompanying the manuscript *"Sovereign-PM: a multimodal reinforcement learning framework for
carbon-aware multi-mode project scheduling with numerically certified guarantees"*
(submitted to *Frontiers in Artificial Intelligence*).

A single script regenerates **every number, table and figure** in the manuscript and in the
Supplementary Material. Everything trainable (semantic risk trunk, PPO policy and value networks,
LoRA adapters, Bradley–Terry preference heads) is implemented in NumPy with hand-derived gradients;
there is no GPU, deep-learning framework or network dependency.

## Contents

| Path | What it is |
|---|---|
| `sovereign_pm.py` | Complete implementation and experiment pipeline (Jupytext "percent" format: runs as a script or opens as a notebook). |
| `Sovereign_PM.ipynb` | The same code as a Jupyter notebook (generated from the script with Jupytext; outputs cleared). |
| `requirements.txt` | Exact package versions used for the reported run. |
| `reproduce.sh` | One-command reproduction. |
| `data/psplib/` | The two public benchmark files used in the benchmark-topology evaluation, with provenance (`SOURCE.md`). |
| `expected_outputs/` | Outputs of the reported run: full console log, `results_summary.json`, all CSV tables. Use these to check your reproduction. |

## Reproducing the paper

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
bash reproduce.sh            # or: python sovereign_pm.py
```

The full configuration (10 held-out instances x 6 disturbance seeds x 5 sectors = 300 paired runs
per method) runs in about 90 minutes on a 2-core CPU. Outputs are written to
`sovereign_pm_outputs/`:

* `fig1_architecture.png` ... `fig10_schedule.png`, `figS1_training.png`, `figS2_relaxation_front.png`:
  300-dpi RGB figures drawn at their printed size (176 mm wide, all text >= 8 pt).
  Manuscript figure numbers map as follows: Fig. 1 = `fig1`, 2 = `fig3`, 3 = `fig4`, 4 = `fig8`,
  5 = `fig9`, 6 = `fig5`, 7 = `fig6`, 8 = `fig7`, 9 = `fig10`.
* `table*.csv` / `table*.tex`, `raw_results.csv` (one row per evaluation run) and
  `results_summary.json` (every number quoted in the manuscript).
* `stages_full_n10s6/`: resumable checkpoints. Delete this folder to force a full re-run;
  keep it to regenerate the figures in a few minutes.

Environment variables:

| Variable | Default | Effect |
|---|---|---|
| `SPM_FAST` | `0` | `1` runs a reduced smoke test (a few minutes; numbers are not those of the paper). |
| `SPM_TEST_N` | `10` | Held-out test instances per sector. |
| `SPM_SEEDS` | `6` | Duration-disturbance replications per instance. |
| `SPM_OUT` | `sovereign_pm_outputs` | Output directory. |

## Determinism

One global seed (`20260811`) and hash-derived child generators make the run deterministic for a given
NumPy/SciPy/scikit-learn build. The reported run used Python 3.13.16, NumPy 2.5.3, SciPy 1.18.1,
scikit-learn 1.9.1, pandas 3.0.5 and Matplotlib 3.11.2 on Linux x86-64. Different BLAS
libraries or package versions can change floating-point summation order and therefore individual
digits; the qualitative conclusions and statistical tests should not change. Compare your
`results_summary.json` with `expected_outputs/results_summary.json`.

## Map from manuscript to code

| Manuscript | Script section |
|---|---|
| Problem formulation, environment, SSGS decoder, objectives, S-ADEPT reward (Section 3.1) | 3 (`SchedulerEnv`) |
| Semantic map Phi (Section 3.2) | 2 (`SemanticEncoder`) |
| Lemma 1, Theorems 2-3, Proposition 4 and their measurements (Sections 3.3, 4.1) | 6.1-6.5 |
| Preference learning (Sections 3.4, 4.6) | 7 |
| Instance generator, sector specifications (Section 3.5, Supplementary S2) | 1.1-1.2 (`SectorSpec`, `make_instance`) |
| Benchmark parser and benchmark-topology study (Sections 3.5, 4.7) | 1.3 (`parse_mm`, `instance_from_benchmark`) and 12 |
| Policy, PPO, baselines, GA, planning decoder (Sections 3.1, 3.6) | 4-5 |
| Main experiments, ablations, statistics (Sections 3.7, 4.2-4.5) | 8-10, 13 |

## Licence and citation

Please cite the manuscript if you use this code. Choose and add a licence file (for example MIT)
before public release. The benchmark files in `data/psplib/` are redistributed under the terms
described in `data/psplib/SOURCE.md`.
